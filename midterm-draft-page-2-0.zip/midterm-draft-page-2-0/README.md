# Midterm Draft page 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/Maddie-Jensen/pen/WNWoZLV](https://codepen.io/Maddie-Jensen/pen/WNWoZLV).

